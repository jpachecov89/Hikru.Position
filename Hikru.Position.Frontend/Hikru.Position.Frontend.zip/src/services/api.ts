import axios from 'axios';
import { Position } from '../types/position';

const API_BASE_URL = '/api/positions';

export const getPositions = async (): Promise<Position[]> => {
  const response = await axios.get(API_BASE_URL);
  return response.data;
};

export const getPositionById = async (id: string): Promise<Position> => {
  const response = await axios.get(`${API_BASE_URL}/${id}`);
  return response.data;
};

export const createPosition = async (position: Position): Promise<Position> => {
  const response = await axios.post(API_BASE_URL, position);
  return response.data;
};

export const updatePosition = async (id: string, position: Position): Promise<Position> => {
  const response = await axios.put(`${API_BASE_URL}/${id}`, position);
  return response.data;
};

export const deletePosition = async (id: string): Promise<void> => {
  await axios.delete(`${API_BASE_URL}/${id}`);
};