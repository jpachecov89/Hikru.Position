export interface Position {
  id: string;
  title: string;
  description: string;
}