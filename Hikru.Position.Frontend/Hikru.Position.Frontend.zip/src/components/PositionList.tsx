import React, { useEffect } from 'react';
import { usePositionContext } from '../context/PositionContext';
import { getPositions } from '../services/api';

const PositionList: React.FC = () => {
  const { positions, setPositions } = usePositionContext();

  useEffect(() => {
    const fetchPositions = async () => {
      const data = await getPositions();
      setPositions(data);
    };
    fetchPositions();
  }, [setPositions]);

  return (
    <div>
      <h1>Listado de Posiciones</h1>
      <ul>
        {positions.map((position) => (
          <li key={position.id}>{position.title}</li>
        ))}
      </ul>
    </div>
  );
};

export default PositionList;