import React from 'react';
import PositionList from '../components/PositionList';

const HomePage: React.FC = () => {
  return (
    <div>
      <h1>Listado de Posiciones</h1>
      <PositionList />
    </div>
  );
};

export default HomePage;